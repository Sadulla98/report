<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
        <!-- Scripts -->

    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Page Heading -->






            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"> </script>
        <script src="https://js.pusher.com/7.2/pusher.min.js"></script>

        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

        <script>
            $(document).ready(function () {

                let sessionSuccess ="<?php echo e(session('success')); ?>";
                if(sessionSuccess){
                    toastr.success(sessionSuccess)
                }
                let sessionWarning = "<?php echo e(session('warning')); ?>";
                if(sessionWarning){
                    toastr.success(sessionWarning)
                }
                let sessionError = "<?php echo e(session('error')); ?>";
                if(sessionError){
                    toastr.success(sessionError)
                }

                // Enable pusher logging - don't include this in production
                Pusher.logToConsole = true;

                var pusher = new Pusher('e34714d50c0b6a19a70c', {
                    cluster: 'ap2',
                    forceTLS: false,
                });

                var channel = pusher.subscribe('task');
                channel.bind('notice', function(data) {
                    alert(JSON.stringify(data));
                });

            });
        </script>

    </body>
</html>
<?php /**PATH D:\openserver_new\OpenServer\domains\task\resources\views/layouts/app.blade.php ENDPATH**/ ?>