<div>
    <div>Username: {{ $aplication->user->name }}</div>
    Application
    <div>Id: {{ $aplication->id }}</div>
    <div>Subject: {{ $aplication->subject }}</div>
    <div>Message: {{ $aplication->message }}</div>
</div>
